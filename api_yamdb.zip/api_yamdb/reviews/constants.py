import datetime

NAME_LENGHT = 256
SLUG_LENGHT = 50
TEXT_LENGTH = 25
THIS_YEAR = datetime.datetime.now().year
